﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PresentationLayer;
using BusinessLayer;
using DataLayer;
using Shared;
using Shared.Models;

namespace PresentationLayerWeb
{
    public partial class Log : System.Web.UI.Page
    {
        readonly GoldenRoadBusiness goldenRoadBusiness = new GoldenRoadBusiness();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
        protected void ButtonLogin_Click(object sender, EventArgs e)
        {
            if (TextBoxUserId.Text == "" || TextBoxUserPassword.Text == "")
            {
                return;
            }

            //ne regex nego uslovi

            foreach (User user in goldenRoadBusiness.GetAllUsers())
            {
                if (user.Korisnicki_Id == TextBoxUserId.Text && user.Lozinka == TextBoxUserPassword.Text)
                {
                    return;
                }
            }
            return;
        }
    }
}